﻿namespace TogetherCulture.Infrastructure;
public class Class1
{

}
