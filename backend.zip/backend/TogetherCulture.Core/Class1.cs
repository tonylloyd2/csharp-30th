﻿namespace TogetherCulture.Core;
public class Class1
{

}
