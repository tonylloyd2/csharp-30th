namespace TogetherCulture.Core.DTOs
{
    public class BenefitDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsUsed { get; set; }
    }
}