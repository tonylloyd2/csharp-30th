namespace TogetherCulture.Core.Entities.Enums
{
    public enum ListingType
    {
        Offer,
        Need
    }
}